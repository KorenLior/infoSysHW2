package entity;

import java.sql.Date;

public class Employee {
	private int ID;
	private Date birthDate;
	private String gender;
	private String nationality;
	private boolean car;
	private int status, numChildren, branchNum;
	public Employee(int ID, 
			Date birthDate, 
			String Gender, 
			String Nathionality, 
			boolean car, 
			int status, 
			int numChildren,
			int branchNum) {
		this.ID = ID;
		this.birthDate = birthDate;
		this.branchNum = branchNum;
		this.birthDate = birthDate;
		this.car = car;
		this.ID = ID;
		this.status = status;
		this.numChildren = numChildren;
	}
	public int getID() {
		return ID;
	}
	public Date getBirthDate() {
		return birthDate;
	}
	public String getGender() {
		return gender;
	}
	public String getNationality() {
		return nationality;
	}
	public boolean isCar() {
		return car;
	}
	public int getStatus() {
		return status;
	}
	public int getNumChildren() {
		return numChildren;
	}
	public int getBranchNum() {
		return branchNum;
	}
	@Override
	public String toString() {
		return "Employee [ID=" + ID + ", birthDate=" + birthDate + ", gender=" + gender + ", nationality=" + nationality
				+ ", car=" + car + ", status=" + status + ", numChildren=" + numChildren + ", branchNum=" + branchNum
				+ "]";
	}

}
