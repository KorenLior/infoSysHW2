package control;

public class ctrlLogin {

	public ctrlLogin(int ID) {
		// TODO Auto-generated constructor stub
	}
}
