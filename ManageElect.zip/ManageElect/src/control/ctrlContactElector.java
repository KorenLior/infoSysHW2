package control;

public class ctrlContactElector {

	public ctrlContactElector() {
		// TODO Auto-generated constructor stub
	}
	
}
