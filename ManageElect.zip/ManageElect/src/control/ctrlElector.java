package control;

public class ctrlElector {

	public ctrlElector(int ID) {
		// TODO Auto-generated constructor stub
	}
	
	public int getElectorPhone() {
		return 8765;
	}
	
	public String getElectorName() {
		return "moshe";
	}
}
